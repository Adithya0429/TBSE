﻿using System;

namespace AJ_EDITS
{
    partial class Front_edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Front_edit));
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_grayscale = new System.Windows.Forms.Button();
            this.dark_mode = new System.Windows.Forms.Button();
            this.sepia_btn = new System.Windows.Forms.Button();
            this.negative_btn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.horizontal_flip_btn = new System.Windows.Forms.Button();
            this.vertical_flip_btn = new System.Windows.Forms.Button();
            this.rotate_right_btn = new System.Windows.Forms.Button();
            this.rotate_left_btn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.red_bar = new System.Windows.Forms.TrackBar();
            this.green_bar = new System.Windows.Forms.TrackBar();
            this.blue_bar = new System.Windows.Forms.TrackBar();
            this.brightness_bar = new System.Windows.Forms.TrackBar();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.label_brightness = new System.Windows.Forms.Label();
            this.label_blue = new System.Windows.Forms.Label();
            this.label_red = new System.Windows.Forms.Label();
            this.label_green = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cropImageToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editMoreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.red_bar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green_bar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blue_bar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.brightness_bar)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(684, 412);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "ADD";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(179, 86);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(717, 292);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(684, 442);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "SAVE";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(766, 412);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 3;
            this.button3.Text = "DELETE";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Broadway", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(406, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(170, 31);
            this.label1.TabIndex = 4;
            this.label1.Text = "AJ EDITES";
            // 
            // btn_grayscale
            // 
            this.btn_grayscale.Location = new System.Drawing.Point(8, 267);
            this.btn_grayscale.Name = "btn_grayscale";
            this.btn_grayscale.Size = new System.Drawing.Size(75, 23);
            this.btn_grayscale.TabIndex = 5;
            this.btn_grayscale.Text = "Grayscale";
            this.btn_grayscale.UseVisualStyleBackColor = true;
            this.btn_grayscale.Click += new System.EventHandler(this.btn_grayscale_Click);
            // 
            // dark_mode
            // 
            this.dark_mode.Location = new System.Drawing.Point(8, 296);
            this.dark_mode.Name = "dark_mode";
            this.dark_mode.Size = new System.Drawing.Size(75, 23);
            this.dark_mode.TabIndex = 6;
            this.dark_mode.Text = "Dark Mode";
            this.dark_mode.UseVisualStyleBackColor = true;
            this.dark_mode.Click += new System.EventHandler(this.dark_mode_Click);
            // 
            // sepia_btn
            // 
            this.sepia_btn.Location = new System.Drawing.Point(89, 267);
            this.sepia_btn.Name = "sepia_btn";
            this.sepia_btn.Size = new System.Drawing.Size(75, 23);
            this.sepia_btn.TabIndex = 7;
            this.sepia_btn.Text = "Sepia";
            this.sepia_btn.UseVisualStyleBackColor = true;
            this.sepia_btn.Click += new System.EventHandler(this.sepia_btn_Click);
            // 
            // negative_btn
            // 
            this.negative_btn.Location = new System.Drawing.Point(89, 296);
            this.negative_btn.Name = "negative_btn";
            this.negative_btn.Size = new System.Drawing.Size(75, 23);
            this.negative_btn.TabIndex = 8;
            this.negative_btn.Text = "Nrgative";
            this.negative_btn.UseVisualStyleBackColor = true;
            this.negative_btn.Click += new System.EventHandler(this.negative_btn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(20, 237);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 16);
            this.label2.TabIndex = 9;
            this.label2.Text = "Editing Options";
            // 
            // horizontal_flip_btn
            // 
            this.horizontal_flip_btn.Location = new System.Drawing.Point(13, 106);
            this.horizontal_flip_btn.Name = "horizontal_flip_btn";
            this.horizontal_flip_btn.Size = new System.Drawing.Size(119, 23);
            this.horizontal_flip_btn.TabIndex = 10;
            this.horizontal_flip_btn.Text = "Horizontal Flip";
            this.horizontal_flip_btn.UseVisualStyleBackColor = true;
            this.horizontal_flip_btn.Click += new System.EventHandler(this.horizontal_flip_btn_Click);
            // 
            // vertical_flip_btn
            // 
            this.vertical_flip_btn.Location = new System.Drawing.Point(13, 136);
            this.vertical_flip_btn.Name = "vertical_flip_btn";
            this.vertical_flip_btn.Size = new System.Drawing.Size(119, 23);
            this.vertical_flip_btn.TabIndex = 11;
            this.vertical_flip_btn.Text = "Vertical Flip";
            this.vertical_flip_btn.UseVisualStyleBackColor = true;
            this.vertical_flip_btn.Click += new System.EventHandler(this.vertical_flip_btn_Click);
            // 
            // rotate_right_btn
            // 
            this.rotate_right_btn.Location = new System.Drawing.Point(13, 165);
            this.rotate_right_btn.Name = "rotate_right_btn";
            this.rotate_right_btn.Size = new System.Drawing.Size(119, 23);
            this.rotate_right_btn.TabIndex = 12;
            this.rotate_right_btn.Text = "Rotate Right";
            this.rotate_right_btn.UseVisualStyleBackColor = true;
            this.rotate_right_btn.Click += new System.EventHandler(this.rotate_right_btn_Click);
            // 
            // rotate_left_btn
            // 
            this.rotate_left_btn.Location = new System.Drawing.Point(13, 194);
            this.rotate_left_btn.Name = "rotate_left_btn";
            this.rotate_left_btn.Size = new System.Drawing.Size(119, 23);
            this.rotate_left_btn.TabIndex = 13;
            this.rotate_left_btn.Text = "Rotate  Left";
            this.rotate_left_btn.UseVisualStyleBackColor = true;
            this.rotate_left_btn.Click += new System.EventHandler(this.rotate_left_btn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(20, 71);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 16);
            this.label3.TabIndex = 14;
            this.label3.Text = "Fliping Options";
            // 
            // red_bar
            // 
            this.red_bar.Location = new System.Drawing.Point(206, 412);
            this.red_bar.Name = "red_bar";
            this.red_bar.Size = new System.Drawing.Size(160, 45);
            this.red_bar.TabIndex = 15;
            this.red_bar.Scroll += new System.EventHandler(this.red_bar_Scroll);
            // 
            // green_bar
            // 
            this.green_bar.Location = new System.Drawing.Point(206, 463);
            this.green_bar.Name = "green_bar";
            this.green_bar.Size = new System.Drawing.Size(160, 45);
            this.green_bar.TabIndex = 17;
            this.green_bar.Scroll += new System.EventHandler(this.green_bar_Scroll);
            // 
            // blue_bar
            // 
            this.blue_bar.Location = new System.Drawing.Point(492, 412);
            this.blue_bar.Name = "blue_bar";
            this.blue_bar.Size = new System.Drawing.Size(148, 45);
            this.blue_bar.TabIndex = 19;
            this.blue_bar.Scroll += new System.EventHandler(this.blue_bar_Scroll);
            // 
            // brightness_bar
            // 
            this.brightness_bar.Location = new System.Drawing.Point(492, 463);
            this.brightness_bar.Name = "brightness_bar";
            this.brightness_bar.Size = new System.Drawing.Size(148, 45);
            this.brightness_bar.TabIndex = 21;
            this.brightness_bar.Scroll += new System.EventHandler(this.brightness_bar_Scroll);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(308, 390);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(178, 16);
            this.label4.TabIndex = 23;
            this.label4.Text = "RGB AND BRIGHTNESS";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(149, 420);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 13);
            this.label5.TabIndex = 24;
            this.label5.Text = "RED";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(149, 463);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 25;
            this.label6.Text = "GREEN";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(409, 420);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 13);
            this.label7.TabIndex = 26;
            this.label7.Text = "BLUE";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(409, 463);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 13);
            this.label8.TabIndex = 27;
            this.label8.Text = "BRIGHTNESS";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(766, 442);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 28;
            this.button4.Text = "RESET";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(8, 344);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(101, 45);
            this.button5.TabIndex = 29;
            this.button5.Text = "Crop a Image";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label_brightness
            // 
            this.label_brightness.AutoSize = true;
            this.label_brightness.Location = new System.Drawing.Point(649, 452);
            this.label_brightness.Name = "label_brightness";
            this.label_brightness.Size = new System.Drawing.Size(0, 13);
            this.label_brightness.TabIndex = 22;
            // 
            // label_blue
            // 
            this.label_blue.AutoSize = true;
            this.label_blue.Location = new System.Drawing.Point(649, 422);
            this.label_blue.Name = "label_blue";
            this.label_blue.Size = new System.Drawing.Size(0, 13);
            this.label_blue.TabIndex = 20;
            // 
            // label_red
            // 
            this.label_red.AutoSize = true;
            this.label_red.Location = new System.Drawing.Point(372, 420);
            this.label_red.Name = "label_red";
            this.label_red.Size = new System.Drawing.Size(0, 13);
            this.label_red.TabIndex = 16;
            // 
            // label_green
            // 
            this.label_green.AutoSize = true;
            this.label_green.Location = new System.Drawing.Point(372, 463);
            this.label_green.Name = "label_green";
            this.label_green.Size = new System.Drawing.Size(0, 13);
            this.label_green.TabIndex = 18;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.optionsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(942, 24);
            this.menuStrip1.TabIndex = 30;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.deleteToolStripMenuItem,
            this.resetToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // addToolStripMenuItem
            // 
            this.addToolStripMenuItem.Name = "addToolStripMenuItem";
            this.addToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.addToolStripMenuItem.Text = "Add";
            this.addToolStripMenuItem.Click += new System.EventHandler(this.addToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(107, 22);
            this.resetToolStripMenuItem.Text = "Reset";
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.resetToolStripMenuItem_Click);
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.cropImageToolStripMenuItem,
            this.editMoreToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // cropImageToolStripMenuItem
            // 
            this.cropImageToolStripMenuItem.Name = "cropImageToolStripMenuItem";
            this.cropImageToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.cropImageToolStripMenuItem.Text = "Crop Image";
            this.cropImageToolStripMenuItem.Click += new System.EventHandler(this.cropImageToolStripMenuItem_Click);
            // 
            // editMoreToolStripMenuItem
            // 
            this.editMoreToolStripMenuItem.Name = "editMoreToolStripMenuItem";
            this.editMoreToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.editMoreToolStripMenuItem.Text = "Edit More";
            this.editMoreToolStripMenuItem.Click += new System.EventHandler(this.editMoreToolStripMenuItem_Click);
            // 
            // Front_edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(942, 502);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label_brightness);
            this.Controls.Add(this.brightness_bar);
            this.Controls.Add(this.label_blue);
            this.Controls.Add(this.blue_bar);
            this.Controls.Add(this.label_green);
            this.Controls.Add(this.green_bar);
            this.Controls.Add(this.label_red);
            this.Controls.Add(this.red_bar);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.rotate_left_btn);
            this.Controls.Add(this.rotate_right_btn);
            this.Controls.Add(this.vertical_flip_btn);
            this.Controls.Add(this.horizontal_flip_btn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.negative_btn);
            this.Controls.Add(this.sepia_btn);
            this.Controls.Add(this.dark_mode);
            this.Controls.Add(this.btn_grayscale);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Front_edit";
            this.Text = "AJ EDITS";
            this.TransparencyKey = System.Drawing.Color.White;
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.red_bar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green_bar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blue_bar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.brightness_bar)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

      

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_grayscale;
        private System.Windows.Forms.Button dark_mode;
        private System.Windows.Forms.Button sepia_btn;
        private System.Windows.Forms.Button negative_btn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button horizontal_flip_btn;
        private System.Windows.Forms.Button vertical_flip_btn;
        private System.Windows.Forms.Button rotate_right_btn;
        private System.Windows.Forms.Button rotate_left_btn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TrackBar red_bar;
        private System.Windows.Forms.TrackBar green_bar;
        private System.Windows.Forms.TrackBar blue_bar;
        private System.Windows.Forms.TrackBar brightness_bar;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label_brightness;
        private System.Windows.Forms.Label label_blue;
        private System.Windows.Forms.Label label_red;
        private System.Windows.Forms.Label label_green;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cropImageToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editMoreToolStripMenuItem;
    }
}

