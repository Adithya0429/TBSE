﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AJ_EDITS
{
    public partial class Edit_more : Form
    {
        public Edit_more()
        {
            InitializeComponent();
        }

        Image picture_01;
        Image picture_02;
        Boolean open_picture_1 = false;
        Boolean open_picture_2 = false;

        Methods methods = new Methods();

        //Add Button 01
        private void add_btn_1_Click(object sender, EventArgs e)
        {
            Add_Image_1();
        }

        //Add image funuction 01
        public void Add_Image_1()
        {
            try
            {
                DialogResult dr = openFileDialog1.ShowDialog();
                if (dr == DialogResult.OK)
                {
                    picture_01 = Image.FromFile(openFileDialog1.FileName);
                    pictureBox1.Image = picture_01;
                    open_picture_1 = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }

        //Add Image button 02
        private void add_btn_2_Click(object sender, EventArgs e)
        {
            Add_Image_2();
        }

        //Add image funuction 02
        public void Add_Image_2()
        {
            try
            {
                DialogResult dr = openFileDialog2.ShowDialog();
                if (dr == DialogResult.OK)
                {
                    picture_02 = Image.FromFile(openFileDialog2.FileName);
                    pictureBox2.Image = picture_02;
                    open_picture_2 = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }

        //Save button 01
        private void save_btn_1_Click(object sender, EventArgs e)
        {
            Save_picutre_1();
        }

        //Save image function 01
        public void Save_picutre_1()
        {
            if (open_picture_1)
            {

                SaveFileDialog save_pic_1 = new SaveFileDialog();
                save_pic_1.Filter = "Images|*.png;*.jpg*;.bmp*";
                ImageFormat format = ImageFormat.Png;


                if (save_pic_1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    string extension = Path.GetExtension(save_pic_1.FileName);

                    switch (extension)
                    {

                        case ".jpg":
                            format = ImageFormat.Jpeg;
                            break;

                        case ".png":
                            format = ImageFormat.Png;
                            break;
                    }

                    pictureBox1.Image.Save(save_pic_1.FileName, format);
                }


            }
            else
            {
                MessageBox.Show("LOAD A IMAGE TO THE BOX AND SAVE !!");
            }

        }

        //Save button 02
        private void save_btn_2_Click(object sender, EventArgs e)
        {
            Save_picutre_2();
        }

        //Save button function 02
        public void Save_picutre_2()
        {
            if (open_picture_2)
            {

                SaveFileDialog save_pic_2 = new SaveFileDialog();
                save_pic_2.Filter = "Images|*.png;*.jpg*;.bmp*";
                ImageFormat format = ImageFormat.Png;


                if (save_pic_2.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    string extension = Path.GetExtension(save_pic_2.FileName);

                    switch (extension)
                    {

                        case ".jpg":
                            format = ImageFormat.Jpeg;
                            break;

                        case ".png":
                            format = ImageFormat.Png;
                            break;
                    }

                    pictureBox2.Image.Save(save_pic_2.FileName, format);
                }
            }
            else
            {
                MessageBox.Show("LOAD A IMAGE TO THE BOX AND SAVE !!");
            }
        }

        //Delete button 01
        private void delete_btn_1_Click(object sender, EventArgs e)
        {
            Delete_Picture_1();
        }

        //Delete function 01
        public void Delete_Picture_1()
        {
            pictureBox1.Image = null;
        }
        //Delete button 02
        private void delete_btn_2_Click(object sender, EventArgs e)
        {
            Delete_Picture_2();
        }
        //Delete function 02
        public void Delete_Picture_2()
        {
            pictureBox2.Image = null;
        }

        //BACK button
        private void back_more_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Front_edit front_Edit = new Front_edit();
            front_Edit.Show();
        }

        //Chnage RGB method 1
        public void change_RGB1()
        {
            float red = red_bar.Value * 0.1f;
            float green = green_bar.Value * 0.1f;
            float blue = blu_bar.Value * 0.1f;
            float brightness = brightness_bar.Value * 0.1f;
            picture_refresh_1();
            picture_01 = pictureBox1.Image;
           

            Bitmap bitmap = new Bitmap(picture_01.Width, picture_01.Height);
            ImageAttributes imageAttributes = new ImageAttributes();
            ColorMatrix colorMatrix = new ColorMatrix(new float[][]
            {
                new float[]{1+red,0 ,0 ,0 , 0 ,},
                new float[]{0 ,1+green, 0, 0, 0,},
                new float[]{0, 0,1+blue, 0, 0 ,},
                new float[]{0, 0, 0, 1, 0},
                new  float[]{brightness,brightness,brightness, 0, 1}
            });

            imageAttributes.SetColorMatrix(colorMatrix);
            Graphics graphics = Graphics.FromImage(bitmap);
            graphics.DrawImage(picture_01, new Rectangle(0, 0, picture_01.Width, picture_01.Height), 0, 0, picture_01.Width, picture_01.Height, GraphicsUnit.Pixel, imageAttributes);
            graphics.Dispose();
            pictureBox1.Image = bitmap;

        }

        //Chnage RGB method 2
        public void change_RGB2()
        {
            float red = red_bar.Value * 0.1f;
            float green = green_bar.Value * 0.1f;
            float blue = blu_bar.Value * 0.1f;
            float brightness = brightness_bar.Value * 0.1f;

            picture_refresh_2();
            picture_02 = pictureBox2.Image;
           

            Bitmap bitmap = new Bitmap(picture_02.Width, picture_02.Height);
            ImageAttributes imageAttributes = new ImageAttributes();
            ColorMatrix colorMatrix = new ColorMatrix(new float[][]
            {
                new float[]{1+red,0 ,0 ,0 , 0 ,},
                new float[]{0 ,1+green, 0, 0, 0,},
                new float[]{0, 0,1+blue, 0, 0 ,},
                new float[]{0, 0, 0, 1, 0},
                new  float[]{brightness,brightness,brightness, 0, 1}
            });

            imageAttributes.SetColorMatrix(colorMatrix);
            Graphics graphics = Graphics.FromImage(bitmap);
            graphics.DrawImage(picture_02, new Rectangle(0, 0, picture_02.Width, picture_02.Height), 0, 0, picture_02.Width, picture_02.Height, GraphicsUnit.Pixel, imageAttributes);
            graphics.Dispose();
            pictureBox2.Image = bitmap;

        }
        //Red bar
        private void red_bar_Scroll(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                change_RGB1();
            }
            else if (checkBox2.Checked)
            {
                change_RGB2();
            }
            else if (checkBox1.Checked && checkBox2.Checked)
            {
                MessageBox.Show("You can Select The Both");
                checkBox1.Checked = false;
                checkBox2.Checked = false;
            }
            else
            {
                MessageBox.Show("Select A Picture To edit");
            }
        }

        //Picture refresh method
        public void picture_refresh_1()
        {
            pictureBox1.Image = picture_01;
            
        }

        //Picture refresh method
        public void picture_refresh_2()
        {
            
            pictureBox2.Image = picture_02;
        }

        //Gray Scale btn
        private void gray_scale_btn_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                Task task = Task.Factory.StartNew(() =>
                {
                    Image picture = pictureBox1.Image;
                    Bitmap grayscale_filling = new Bitmap(picture);
                    methods.Grayscale(grayscale_filling);
                    this.pictureBox1.Image = grayscale_filling;
                });
            }

            if (checkBox2.Checked)
            {
                Task task = Task.Factory.StartNew(() =>
                {
                    Image picture = pictureBox2.Image;
                    Bitmap grayscale_filling = new Bitmap(picture);
                    methods.Grayscale(grayscale_filling);
                    this.pictureBox2.Image = grayscale_filling;
                });
            }

        }
        //Sepia function
        private void Sepia_btn_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                Task task = Task.Factory.StartNew(() =>
                {

                    Image picture = pictureBox1.Image;
                    Bitmap sepia_filling = new Bitmap(picture);
                    methods.Sepia(sepia_filling);
                    this.pictureBox1.Image = sepia_filling;


                });
            }


            if (checkBox2.Checked)
            {
                Task task = Task.Factory.StartNew(() =>
                {

                    Image picture = pictureBox2.Image;
                    Bitmap sepia_filling = new Bitmap(picture);
                    methods.Sepia(sepia_filling);
                    this.pictureBox2.Image = sepia_filling;


                });
            }
        }

        //Blue bar
        private void blu_bar_Scroll(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                change_RGB1();
            }
            else if (checkBox2.Checked)
            {
                change_RGB2();
            }
            else if (checkBox1.Checked && checkBox2.Checked)
            {
                MessageBox.Show("You can Select The Both");
                checkBox1.Checked = false;
                checkBox2.Checked = false;
            }
            else
            {
                MessageBox.Show("Select A Picture To edit");
            }
        }

        //Green bar
        private void green_bar_Scroll(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                change_RGB1();
            }
            else if (checkBox2.Checked)
            {
                change_RGB2();
            }
            else if (checkBox1.Checked && checkBox2.Checked)
            {
                MessageBox.Show("You can Select The Both");
                checkBox1.Checked = false;
                checkBox2.Checked = false;
            }
            else
            {
                MessageBox.Show("Select A Picture To edit");
            }
        }

        //Brightness bar
        private void brightness_bar_Scroll(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                change_RGB1();
            }
            else if (checkBox2.Checked)
            {
                change_RGB2();
            }
            else if (checkBox1.Checked && checkBox2.Checked)
            {
                MessageBox.Show("You can Select The Both");
                checkBox1.Checked = false;
                checkBox2.Checked = false;
            }
            else
            {
                MessageBox.Show("Select A Picture To edit");
            }
        }
        //Dark mode btn
        private void darkmode_btn_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                Task task = Task.Factory.StartNew(() =>
                {
                    Image picture = pictureBox1.Image;
                    Bitmap dark_mode_filling = new Bitmap(picture);
                    methods.Dark_mode(dark_mode_filling);
                    this.pictureBox1.Image = dark_mode_filling;
                });
            }


            if (checkBox2.Checked)
            {
                Task task = Task.Factory.StartNew(() =>
                {
                    Image picture = pictureBox2.Image;
                    Bitmap dark_mode_filling = new Bitmap(picture);
                    methods.Dark_mode(dark_mode_filling);
                    this.pictureBox2.Image = dark_mode_filling;
                });
            }
        }

        private void negative_btn_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                Task task = Task.Factory.StartNew(() =>
                {

                    Image picture = pictureBox1.Image;
                    Bitmap negative_filling = new Bitmap(picture);
                    methods.Negative(negative_filling);
                    this.pictureBox1.Image = negative_filling;


                });
            }


            if (checkBox2.Checked)
            {
                Task task = Task.Factory.StartNew(() =>
                {

                    Image picture = pictureBox2.Image;
                    Bitmap negative_filling = new Bitmap(picture);
                    methods.Negative(negative_filling);
                    this.pictureBox2.Image = negative_filling;


                });
            }
        }

        //Reset image function
        public void reset_image_1()
        {

            if (!open_picture_1)
            {
                MessageBox.Show("Please edit the image");
            }
            else
            {
                if (open_picture_1)
                {
                    picture_01 = Image.FromFile(openFileDialog1.FileName);
                    pictureBox1.Image = picture_01;
                    open_picture_1 = true;

                    Task t1none = new Task(() =>
                    {
                        none_01();
                    });
                    t1none.Start(TaskScheduler.FromCurrentSynchronizationContext());
                }
            }
        }

        public void reset_image_2()
        {

            if (!open_picture_2)
            {
                MessageBox.Show("Please edit the image");
            }
            else
            {
                if (open_picture_2)
                {
                    picture_02 = Image.FromFile(openFileDialog2.FileName);
                    pictureBox2.Image = picture_02;
                    open_picture_2 = true;

                    Task t2none = new Task(() =>
                    {
                        none_02();
                    });
                    t2none.Start(TaskScheduler.FromCurrentSynchronizationContext());
                }
            }
        }

        //Bar change to 0 method
        public void none_01()
        {
            Task task1 = new Task(() =>
            {
                pictureBox1.Image = picture_01;

                this.red_bar.Value = 0;
                this.green_bar.Value = 0;
                this.blu_bar.Value = 0;
                this.brightness_bar.Value = 0;
            });            

            task1.Start(TaskScheduler.FromCurrentSynchronizationContext());
        }


        public void none_02()
        {
            Task task2 = new Task(() =>
            {
                pictureBox2.Image = picture_02;

                this.red_bar.Value = 0;
                this.green_bar.Value = 0;
                this.blu_bar.Value = 0;
                this.brightness_bar.Value = 0;
            });

            task2.Start(TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void reset_btn_1_Click(object sender, EventArgs e)
        {
            reset_image_1();
        }

        private void reset_btn_01_Click(object sender, EventArgs e)
        {
            reset_image_2();
        }

        //Vertical flip
        private void flip_vertical_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {

                Task task = Task.Factory.StartNew(() =>
                {
                    Image picture = pictureBox1.Image;
                    methods.Vertical_flip(picture);
                    this.pictureBox1.Image = picture;
                });
            }

            if (checkBox2.Checked)
            {
                Task task = Task.Factory.StartNew(() =>
                {
                    Image picture = pictureBox2.Image;
                    methods.Vertical_flip(picture);
                    this.pictureBox2.Image = picture;
                });
            }
        }

        //Horizontal Flip
        private void hoorizon_fip_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {

                Task task = Task.Factory.StartNew(() =>
                {
                    Image picture = pictureBox1.Image;
                    methods.Horizontal_flip(picture);
                    this.pictureBox1.Image = picture;
                });
            }

            if (checkBox2.Checked)
            {
                Task task = Task.Factory.StartNew(() =>
                {
                    Image picture = pictureBox2.Image;
                    methods.Horizontal_flip(picture);
                    this.pictureBox2.Image = picture;
                });
            }
        }

        private void rotate_right_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {

                Task task = Task.Factory.StartNew(() =>
                {
                    Image picture = pictureBox1.Image;
                    methods.Rotate_right(picture);
                    this.pictureBox1.Image = picture;
                });
            }

            if (checkBox2.Checked)
            {
                Task task = Task.Factory.StartNew(() =>
                {
                    Image picture = pictureBox2.Image;
                    methods.Rotate_right(picture);
                    this.pictureBox2.Image = picture;
                });
            }
        }

        private void roate_left_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {

                Task task = Task.Factory.StartNew(() =>
                {
                    Image picture = pictureBox1.Image;
                    methods.Rotate_left(picture);
                    this.pictureBox1.Image = picture;
                });
            }

            if (checkBox2.Checked)
            {
                Task task = Task.Factory.StartNew(() =>
                {
                    Image picture = pictureBox2.Image;
                    methods.Rotate_left(picture);
                    this.pictureBox2.Image = picture;
                });
            }
        }
    }




}



