﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AJ_EDITS
{
    class Methods
    {
        //Rotate Left Mehtod 
        public void Rotate_left(Image rotate_left)
        {
            rotate_left.RotateFlip(RotateFlipType.Rotate270FlipNone);
        }

        //Roate right method
        public void Rotate_right(Image rotate_right)
        {
            rotate_right.RotateFlip(RotateFlipType.Rotate90FlipNone);
        }


        //Verticl method
        public void Vertical_flip(Image vertical_flip)
        {
            vertical_flip.RotateFlip(RotateFlipType.RotateNoneFlipX);
        }

        //Horizontal Fip Method
        public void Horizontal_flip(Image horizontal_flip)
        {
            horizontal_flip.RotateFlip(RotateFlipType.RotateNoneFlipY);

        }

        //Negative filling method
        public void Negative(Bitmap negative_filling)
        {
            int height = negative_filling.Height;
            int width = negative_filling.Width;

            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    Color color = negative_filling.GetPixel(x, y);

                    int a = color.A;
                    int r = color.B;
                    int g = color.R;
                    int b = color.B;

                    r = 255 - r;
                    g = 255 - g;
                    b = 255 - b;

                    negative_filling.SetPixel(x, y, Color.FromArgb(a, r, g, b));
                }
            }
        }

        //Dark mode method
        public void Dark_mode(Bitmap dark_mode_filling)
        {
            int heigt = dark_mode_filling.Height;
            int width = dark_mode_filling.Width;

            Color color;

            for (int y = 0; y < heigt; y++)
            {
                for (int x = 0; x < width; x++)
                {

                    color = dark_mode_filling.GetPixel(x, y);
                    int a = color.A;
                    int r = color.R;
                    int g = color.G;
                    int b = color.B;

                    int averag = (r + g + b) / 3;

                    dark_mode_filling.SetPixel(x, y, Color.FromArgb(a, averag, averag, averag));

                }
            }

        }


        //Grayscale method
        public void Grayscale(Bitmap grayscale_filling)
        {
            int heigt = grayscale_filling.Height;
            int width = grayscale_filling.Width;

            Color color;

            for (int y = 0; y < heigt; y++)
            {
                for (int x = 0; x < width; x++)
                {

                    color = grayscale_filling.GetPixel(x, y);
                    int a = color.A;
                    int r = color.R;
                    int g = color.G;
                    int b = color.B;

                    int averag = (r + g + b) / 3;

                    grayscale_filling.SetPixel(x, y, Color.FromArgb(a, averag, averag, averag));

                }
            }
        }

        //Sepia method
        public void Sepia(Bitmap sepia_filling)
        {
            int height = sepia_filling.Height;
            int width = sepia_filling.Width;


            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    Color color = sepia_filling.GetPixel(x, y);

                    int a = color.A;
                    int r = color.B;
                    int g = color.R;
                    int b = color.B;


                    int tr = (int)(0.393 * r + 0.769 * g + 0.189 * b);
                    int tg = (int)(0.349 * r + 0.686 * g + 0.168 * b);
                    int tb = (int)(0.271 * r + 0.534 * g + 0.131 * b);

                    if (tr > 255)
                    {
                        r = 255;
                    }
                    else
                    {
                        r = tr;
                    }
                    if (tg > 255)
                    {

                        g = 255;
                    }
                    else
                    {
                        g = tg;
                    }
                    if (tb > 255)
                    {
                        b = 255;
                    }
                    else
                    {
                        b = tb;
                    }

                    sepia_filling.SetPixel(x, y, Color.FromArgb(a, r, g, b));

                }
            }
        }
    }
}
