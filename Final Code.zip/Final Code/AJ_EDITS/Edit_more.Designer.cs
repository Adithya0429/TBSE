﻿namespace AJ_EDITS
{
    partial class Edit_more
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Edit_more));
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.add_btn_1 = new System.Windows.Forms.Button();
            this.add_btn_2 = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.save_btn_1 = new System.Windows.Forms.Button();
            this.save_btn_2 = new System.Windows.Forms.Button();
            this.delete_btn_1 = new System.Windows.Forms.Button();
            this.delete_btn_2 = new System.Windows.Forms.Button();
            this.reset_btn_1 = new System.Windows.Forms.Button();
            this.reset_btn_01 = new System.Windows.Forms.Button();
            this.back_more_btn = new System.Windows.Forms.Button();
            this.gray_scale_btn = new System.Windows.Forms.Button();
            this.Sepia_btn = new System.Windows.Forms.Button();
            this.darkmode_btn = new System.Windows.Forms.Button();
            this.negative_btn = new System.Windows.Forms.Button();
            this.red_bar = new System.Windows.Forms.TrackBar();
            this.green_bar = new System.Windows.Forms.TrackBar();
            this.blu_bar = new System.Windows.Forms.TrackBar();
            this.brightness_bar = new System.Windows.Forms.TrackBar();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.flip_vertical = new System.Windows.Forms.Button();
            this.hoorizon_fip = new System.Windows.Forms.Button();
            this.rotate_right = new System.Windows.Forms.Button();
            this.roate_left = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.red_bar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.green_bar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.blu_bar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.brightness_bar)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Broadway", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(418, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "AJ EDITS";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(68, 156);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(317, 229);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(605, 156);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(320, 238);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // add_btn_1
            // 
            this.add_btn_1.Location = new System.Drawing.Point(68, 400);
            this.add_btn_1.Name = "add_btn_1";
            this.add_btn_1.Size = new System.Drawing.Size(75, 23);
            this.add_btn_1.TabIndex = 3;
            this.add_btn_1.Text = "Add";
            this.add_btn_1.UseVisualStyleBackColor = true;
            this.add_btn_1.Click += new System.EventHandler(this.add_btn_1_Click);
            // 
            // add_btn_2
            // 
            this.add_btn_2.Location = new System.Drawing.Point(605, 400);
            this.add_btn_2.Name = "add_btn_2";
            this.add_btn_2.Size = new System.Drawing.Size(75, 23);
            this.add_btn_2.TabIndex = 4;
            this.add_btn_2.Text = "Add";
            this.add_btn_2.UseVisualStyleBackColor = true;
            this.add_btn_2.Click += new System.EventHandler(this.add_btn_2_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.FileName = "openFileDialog2";
            // 
            // save_btn_1
            // 
            this.save_btn_1.Location = new System.Drawing.Point(150, 401);
            this.save_btn_1.Name = "save_btn_1";
            this.save_btn_1.Size = new System.Drawing.Size(75, 23);
            this.save_btn_1.TabIndex = 5;
            this.save_btn_1.Text = "Save";
            this.save_btn_1.UseVisualStyleBackColor = true;
            this.save_btn_1.Click += new System.EventHandler(this.save_btn_1_Click);
            // 
            // save_btn_2
            // 
            this.save_btn_2.Location = new System.Drawing.Point(686, 401);
            this.save_btn_2.Name = "save_btn_2";
            this.save_btn_2.Size = new System.Drawing.Size(75, 23);
            this.save_btn_2.TabIndex = 6;
            this.save_btn_2.Text = "Save";
            this.save_btn_2.UseVisualStyleBackColor = true;
            this.save_btn_2.Click += new System.EventHandler(this.save_btn_2_Click);
            // 
            // delete_btn_1
            // 
            this.delete_btn_1.Location = new System.Drawing.Point(232, 401);
            this.delete_btn_1.Name = "delete_btn_1";
            this.delete_btn_1.Size = new System.Drawing.Size(75, 23);
            this.delete_btn_1.TabIndex = 7;
            this.delete_btn_1.Text = "Delete";
            this.delete_btn_1.UseVisualStyleBackColor = true;
            this.delete_btn_1.Click += new System.EventHandler(this.delete_btn_1_Click);
            // 
            // delete_btn_2
            // 
            this.delete_btn_2.Location = new System.Drawing.Point(767, 400);
            this.delete_btn_2.Name = "delete_btn_2";
            this.delete_btn_2.Size = new System.Drawing.Size(75, 23);
            this.delete_btn_2.TabIndex = 8;
            this.delete_btn_2.Text = "Delete";
            this.delete_btn_2.UseVisualStyleBackColor = true;
            this.delete_btn_2.Click += new System.EventHandler(this.delete_btn_2_Click);
            // 
            // reset_btn_1
            // 
            this.reset_btn_1.Location = new System.Drawing.Point(313, 401);
            this.reset_btn_1.Name = "reset_btn_1";
            this.reset_btn_1.Size = new System.Drawing.Size(75, 23);
            this.reset_btn_1.TabIndex = 9;
            this.reset_btn_1.Text = "Reset";
            this.reset_btn_1.UseVisualStyleBackColor = true;
            this.reset_btn_1.Click += new System.EventHandler(this.reset_btn_1_Click);
            // 
            // reset_btn_01
            // 
            this.reset_btn_01.Location = new System.Drawing.Point(848, 400);
            this.reset_btn_01.Name = "reset_btn_01";
            this.reset_btn_01.Size = new System.Drawing.Size(75, 23);
            this.reset_btn_01.TabIndex = 10;
            this.reset_btn_01.Text = "Reset";
            this.reset_btn_01.UseVisualStyleBackColor = true;
            this.reset_btn_01.Click += new System.EventHandler(this.reset_btn_01_Click);
            // 
            // back_more_btn
            // 
            this.back_more_btn.Location = new System.Drawing.Point(68, 504);
            this.back_more_btn.Name = "back_more_btn";
            this.back_more_btn.Size = new System.Drawing.Size(132, 28);
            this.back_more_btn.TabIndex = 11;
            this.back_more_btn.Text = "Go Back <<";
            this.back_more_btn.UseVisualStyleBackColor = true;
            this.back_more_btn.Click += new System.EventHandler(this.back_more_btn_Click);
            // 
            // gray_scale_btn
            // 
            this.gray_scale_btn.Location = new System.Drawing.Point(412, 226);
            this.gray_scale_btn.Name = "gray_scale_btn";
            this.gray_scale_btn.Size = new System.Drawing.Size(75, 23);
            this.gray_scale_btn.TabIndex = 12;
            this.gray_scale_btn.Text = "GrayScale";
            this.gray_scale_btn.UseVisualStyleBackColor = true;
            this.gray_scale_btn.Click += new System.EventHandler(this.gray_scale_btn_Click);
            // 
            // Sepia_btn
            // 
            this.Sepia_btn.Location = new System.Drawing.Point(504, 226);
            this.Sepia_btn.Name = "Sepia_btn";
            this.Sepia_btn.Size = new System.Drawing.Size(75, 23);
            this.Sepia_btn.TabIndex = 13;
            this.Sepia_btn.Text = "Sepia";
            this.Sepia_btn.UseVisualStyleBackColor = true;
            this.Sepia_btn.Click += new System.EventHandler(this.Sepia_btn_Click);
            // 
            // darkmode_btn
            // 
            this.darkmode_btn.Location = new System.Drawing.Point(412, 256);
            this.darkmode_btn.Name = "darkmode_btn";
            this.darkmode_btn.Size = new System.Drawing.Size(75, 23);
            this.darkmode_btn.TabIndex = 14;
            this.darkmode_btn.Text = "Dark Mode";
            this.darkmode_btn.UseVisualStyleBackColor = true;
            this.darkmode_btn.Click += new System.EventHandler(this.darkmode_btn_Click);
            // 
            // negative_btn
            // 
            this.negative_btn.Location = new System.Drawing.Point(504, 256);
            this.negative_btn.Name = "negative_btn";
            this.negative_btn.Size = new System.Drawing.Size(75, 23);
            this.negative_btn.TabIndex = 15;
            this.negative_btn.Text = "Negative";
            this.negative_btn.UseVisualStyleBackColor = true;
            this.negative_btn.Click += new System.EventHandler(this.negative_btn_Click);
            // 
            // red_bar
            // 
            this.red_bar.Location = new System.Drawing.Point(369, 487);
            this.red_bar.Name = "red_bar";
            this.red_bar.Size = new System.Drawing.Size(104, 45);
            this.red_bar.TabIndex = 17;
            this.red_bar.Scroll += new System.EventHandler(this.red_bar_Scroll);
            // 
            // green_bar
            // 
            this.green_bar.Location = new System.Drawing.Point(532, 487);
            this.green_bar.Name = "green_bar";
            this.green_bar.Size = new System.Drawing.Size(104, 45);
            this.green_bar.TabIndex = 18;
            this.green_bar.Scroll += new System.EventHandler(this.green_bar_Scroll);
            // 
            // blu_bar
            // 
            this.blu_bar.Location = new System.Drawing.Point(369, 521);
            this.blu_bar.Name = "blu_bar";
            this.blu_bar.Size = new System.Drawing.Size(104, 45);
            this.blu_bar.TabIndex = 19;
            this.blu_bar.Scroll += new System.EventHandler(this.blu_bar_Scroll);
            // 
            // brightness_bar
            // 
            this.brightness_bar.Location = new System.Drawing.Point(532, 521);
            this.brightness_bar.Name = "brightness_bar";
            this.brightness_bar.Size = new System.Drawing.Size(104, 45);
            this.brightness_bar.TabIndex = 20;
            this.brightness_bar.Scroll += new System.EventHandler(this.brightness_bar_Scroll);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(336, 487);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 13);
            this.label3.TabIndex = 21;
            this.label3.Text = "Red";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(479, 487);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(36, 13);
            this.label4.TabIndex = 22;
            this.label4.Text = "Green";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(336, 521);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(28, 13);
            this.label5.TabIndex = 23;
            this.label5.Text = "Blue";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(475, 527);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 13);
            this.label6.TabIndex = 24;
            this.label6.Text = "Brightness";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox1.Location = new System.Drawing.Point(187, 131);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(84, 19);
            this.checkBox1.TabIndex = 25;
            this.checkBox1.Text = "Picture 01";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox2.Location = new System.Drawing.Point(717, 131);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(87, 19);
            this.checkBox2.TabIndex = 26;
            this.checkBox2.Text = "Picture  02";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(458, 193);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 18);
            this.label2.TabIndex = 16;
            this.label2.Text = "FILTERS";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(422, 308);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(145, 18);
            this.label7.TabIndex = 27;
            this.label7.Text = "OTHER OPTIONS";
            // 
            // flip_vertical
            // 
            this.flip_vertical.Location = new System.Drawing.Point(401, 339);
            this.flip_vertical.Name = "flip_vertical";
            this.flip_vertical.Size = new System.Drawing.Size(86, 23);
            this.flip_vertical.TabIndex = 28;
            this.flip_vertical.Text = "Vertical Flip";
            this.flip_vertical.UseVisualStyleBackColor = true;
            this.flip_vertical.Click += new System.EventHandler(this.flip_vertical_Click);
            // 
            // hoorizon_fip
            // 
            this.hoorizon_fip.Location = new System.Drawing.Point(493, 339);
            this.hoorizon_fip.Name = "hoorizon_fip";
            this.hoorizon_fip.Size = new System.Drawing.Size(95, 23);
            this.hoorizon_fip.TabIndex = 29;
            this.hoorizon_fip.Text = "Horizontal Flip";
            this.hoorizon_fip.UseVisualStyleBackColor = true;
            this.hoorizon_fip.Click += new System.EventHandler(this.hoorizon_fip_Click);
            // 
            // rotate_right
            // 
            this.rotate_right.Location = new System.Drawing.Point(401, 368);
            this.rotate_right.Name = "rotate_right";
            this.rotate_right.Size = new System.Drawing.Size(86, 23);
            this.rotate_right.TabIndex = 30;
            this.rotate_right.Text = "Rotate Right";
            this.rotate_right.UseVisualStyleBackColor = true;
            this.rotate_right.Click += new System.EventHandler(this.rotate_right_Click);
            // 
            // roate_left
            // 
            this.roate_left.Location = new System.Drawing.Point(493, 369);
            this.roate_left.Name = "roate_left";
            this.roate_left.Size = new System.Drawing.Size(95, 23);
            this.roate_left.TabIndex = 31;
            this.roate_left.Text = "Rotate Left";
            this.roate_left.UseVisualStyleBackColor = true;
            this.roate_left.Click += new System.EventHandler(this.roate_left_Click);
            // 
            // Edit_more
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(962, 574);
            this.Controls.Add(this.roate_left);
            this.Controls.Add(this.rotate_right);
            this.Controls.Add(this.hoorizon_fip);
            this.Controls.Add(this.flip_vertical);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.checkBox2);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.brightness_bar);
            this.Controls.Add(this.blu_bar);
            this.Controls.Add(this.green_bar);
            this.Controls.Add(this.red_bar);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.negative_btn);
            this.Controls.Add(this.darkmode_btn);
            this.Controls.Add(this.Sepia_btn);
            this.Controls.Add(this.gray_scale_btn);
            this.Controls.Add(this.back_more_btn);
            this.Controls.Add(this.reset_btn_01);
            this.Controls.Add(this.reset_btn_1);
            this.Controls.Add(this.delete_btn_2);
            this.Controls.Add(this.delete_btn_1);
            this.Controls.Add(this.save_btn_2);
            this.Controls.Add(this.save_btn_1);
            this.Controls.Add(this.add_btn_2);
            this.Controls.Add(this.add_btn_1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Edit_more";
            this.Text = "Edit_more";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.red_bar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.green_bar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.blu_bar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.brightness_bar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button add_btn_1;
        private System.Windows.Forms.Button add_btn_2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.Button save_btn_1;
        private System.Windows.Forms.Button save_btn_2;
        private System.Windows.Forms.Button delete_btn_1;
        private System.Windows.Forms.Button delete_btn_2;
        private System.Windows.Forms.Button reset_btn_1;
        private System.Windows.Forms.Button reset_btn_01;
        private System.Windows.Forms.Button back_more_btn;
        private System.Windows.Forms.Button gray_scale_btn;
        private System.Windows.Forms.Button Sepia_btn;
        private System.Windows.Forms.Button darkmode_btn;
        private System.Windows.Forms.Button negative_btn;
        private System.Windows.Forms.TrackBar red_bar;
        private System.Windows.Forms.TrackBar green_bar;
        private System.Windows.Forms.TrackBar blu_bar;
        private System.Windows.Forms.TrackBar brightness_bar;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button flip_vertical;
        private System.Windows.Forms.Button hoorizon_fip;
        private System.Windows.Forms.Button rotate_right;
        private System.Windows.Forms.Button roate_left;
    }
}