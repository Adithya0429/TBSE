﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AJ_EDITS
{
    public partial class Crop : Form
    {
        Rectangle rectangle;

        Point LocationXY; //For starting point
        Point LocationX1Y1;  //For ending point

        bool Mouse_down = false;

        Methods methods = new Methods();


        public Crop()
        {
            InitializeComponent();
        }

        private void before_crop_MouseDown(object sender, MouseEventArgs e)
        {
            Mouse_down = true;

            LocationXY = e.Location;
        }

        private void before_crop_MouseMove(object sender, MouseEventArgs e)
        {
            if (Mouse_down == true)
            {
                LocationX1Y1 = e.Location;

                Refresh();
            }
        }

        private void before_crop_MouseUp(object sender, MouseEventArgs e)
        {
            if (Mouse_down == true)
            {
                LocationX1Y1 = e.Location;

                Mouse_down = false;

                if (rectangle != null)
                {
                    Bitmap bit = new Bitmap(before_crop.Image, before_crop.Width, before_crop.Height);

                    Bitmap croping_pic = new Bitmap(rectangle.Width, rectangle.Height);

                    Graphics graphics = Graphics.FromImage(croping_pic);

                    graphics.DrawImage(bit, 0, 0, rectangle, GraphicsUnit.Pixel);

                    after_crop.Image = croping_pic;

                }
            }
        }

        private void before_crop_Paint(object sender, PaintEventArgs e)
        {
            if (rectangle != null)
            {
                e.Graphics.DrawRectangle(Pens.Red, GetRect());
            }
        }

        private  Rectangle GetRect()
        {
            rectangle = new Rectangle();

            rectangle.X = Math.Min(LocationXY.X, LocationX1Y1.X);

            rectangle.Y = Math.Min(LocationXY.Y, LocationX1Y1.Y);

            rectangle.Width = Math.Abs(LocationXY.X - LocationX1Y1.X);

            rectangle.Height = Math.Abs(LocationXY.Y - LocationX1Y1.Y);

            return rectangle;

        }
        //Add pic btn
        private void open_crop_btn_Click(object sender, EventArgs e)
        {
            Open_image_crop();

        }

        //Add imae method
        public void Open_image_crop()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.Filter = "Image Files(*.bmp,*.gif,*.jpg)|*.bmp;*.gif;*.jpg";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                before_crop.Image = Image.FromFile(openFileDialog.FileName, true);
            }
        }

        //Save btn
        private void save_crop_btn_Click(object sender, EventArgs e)
        {
            Save_croped();
        }

        //Save method
        public void Save_croped()
        {

            if (after_crop.Image != null)
            {
                SaveFileDialog save_pic = new SaveFileDialog();
                save_pic.Filter = "Image Files(*.bmp,*.gif,*.jpg)|*.bmp;*.gif;*.jpg";

                if (save_pic.ShowDialog() == DialogResult.OK)
                {
                    if (save_pic.FileName.EndsWith(".bmp"))
                    {
                        after_crop.Image.Save(save_pic.FileName, ImageFormat.Bmp);
                    }

                    else if (save_pic.FileName.EndsWith(".gif"))
                    {
                        after_crop.Image.Save(save_pic.FileName, ImageFormat.Gif);
                    }
                    else if (save_pic.FileName.EndsWith(".jpg"))
                    {
                        after_crop.Image.Save(save_pic.FileName, ImageFormat.Jpeg);
                    }
                }
            }
        }

        //Back button
        private void back_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Front_edit front_Edit = new Front_edit();
            front_Edit.Show();
        }

        



        //Gray Scale
        private void grayScaleToolStripMenuItem_Click(object sender, EventArgs e)
        {

            Task task = Task.Factory.StartNew(() =>
            {
                Image picture = after_crop.Image;
                Bitmap grayscale_filling = new Bitmap(picture);
                methods.Grayscale(grayscale_filling);
                this.after_crop.Image = grayscale_filling;
            });
        }
      
        //Sepia
        private void sepiaToolStripMenuItem_Click(object sender, EventArgs e)
        {          
            Task task = Task.Factory.StartNew(() =>
            {

                Image picture = after_crop.Image;
                Bitmap sepia_filling = new Bitmap(picture);
                methods.Sepia(sepia_filling);
                this.after_crop.Image = sepia_filling;


            });
        }

        //Dark mode
        private void darkModeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Task task = Task.Factory.StartNew(() =>
            {
                Image picture = after_crop.Image;
                Bitmap dark_mode_filling = new Bitmap(picture);
                methods.Dark_mode(dark_mode_filling);
                this.after_crop.Image = dark_mode_filling;
            });
        }

        //Negative
        private void negativeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Task task = Task.Factory.StartNew(() =>
            {

                Image picture = after_crop.Image;
                Bitmap negative_filling = new Bitmap(picture);
                methods.Negative(negative_filling);
                this.after_crop.Image = negative_filling;


            });
        }

        private void horizontalFlipToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Task task = Task.Factory.StartNew(() =>
            {
                Image picture = after_crop.Image;
                methods.Horizontal_flip(picture);
                this.after_crop.Image = picture;
            });
        }

        //Vertical flip
        private void verticalFlipToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Task task = Task.Factory.StartNew(() =>
            {
                Image picture = after_crop.Image;
                methods.Vertical_flip(picture);
                this.after_crop.Image = picture;
            });
        }

        //Rotate left
        private void rotateLeftToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Task t1 = Task.Factory.StartNew(() =>
            {
                Image picture = after_crop.Image;
                methods.Rotate_left(picture);
                this.after_crop.Image = picture;
            });
        }

        //Rotate right
        private void rotateRightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Task t1 = Task.Factory.StartNew(() =>
            {
                Image picture = after_crop.Image;
                methods.Rotate_right(picture);
                this.after_crop.Image = picture;
            });
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Open_image_crop();
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Save_croped();
        }
    }
}
