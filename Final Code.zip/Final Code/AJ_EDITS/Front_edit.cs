﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AJ_EDITS
{
    public partial class Front_edit : Form
    {
        public Front_edit()
        {
            InitializeComponent();
        }

        Image picture;
        Boolean openimage_picture = false;

        Methods methods = new Methods();


        //Add button
        private void button1_Click(object sender, EventArgs e)
        {
            Add_Image();
        }

        //Add image funuction
        public void Add_Image()
        {
            try
            {
                DialogResult dr = openFileDialog1.ShowDialog();
                if (dr == DialogResult.OK)
                {
                    picture = Image.FromFile(openFileDialog1.FileName);
                    pictureBox1.Image = picture;
                    openimage_picture = true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("" + ex);
            }
        }



        //Save button
        private void button2_Click(object sender, EventArgs e)
        {
            Save_picutre();
        }
        //Save function
        public void Save_picutre()
        {
            if (openimage_picture)
            {

                SaveFileDialog save_pic = new SaveFileDialog();
                save_pic.Filter = "Images|*.png;*.jpg*;.bmp*";
                ImageFormat format = ImageFormat.Png;


                if (save_pic.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    string extension = Path.GetExtension(save_pic.FileName);

                    switch (extension)
                    {

                        case ".jpg":
                            format = ImageFormat.Jpeg;
                            break;

                        case ".png":
                            format = ImageFormat.Png;
                            break;
                    }

                    pictureBox1.Image.Save(save_pic.FileName, format);
                }


            }
            else
            {
                MessageBox.Show("LOAD A IMAGE TO THE BOX AND SAVE !!");
            }

        }



        //Delete button
        private void button3_Click(object sender, EventArgs e)
        {
            Delete_Picture();
        }

        //Delete method
        public void Delete_Picture()
        {
            pictureBox1.Image = null;
        }

        //Grayscale button 
        private void btn_grayscale_Click(object sender, EventArgs e)
        {
            Task task = Task.Factory.StartNew(() =>
            {
                Image picture = pictureBox1.Image;
                Bitmap grayscale_filling = new Bitmap(picture);
                methods.Grayscale(grayscale_filling);
                this.pictureBox1.Image = grayscale_filling;
            });
        }       

        //Dark mode button
        private void dark_mode_Click(object sender, EventArgs e)
        {
            Task task = Task.Factory.StartNew(() =>
            {
                Image picture = pictureBox1.Image;
                Bitmap dark_mode_filling = new Bitmap(picture);
                methods.Dark_mode(dark_mode_filling);
                this.pictureBox1.Image = dark_mode_filling;
            });

        }

        
        //Sepia button
        private void sepia_btn_Click(object sender, EventArgs e)
        {
            Task task = Task.Factory.StartNew(() =>
            {
                Image picture = pictureBox1.Image;
                Bitmap sepia_filling = new Bitmap(picture);
                methods.Sepia(sepia_filling);
                this.pictureBox1.Image = sepia_filling;


            });
        }

        //Negative effect button
        private void negative_btn_Click(object sender, EventArgs e)
        {
            Task task = Task.Factory.StartNew(() =>
            {
                Image picture = pictureBox1.Image;
                Bitmap negative_filling = new Bitmap(picture);
                methods.Negative(negative_filling);
                this.pictureBox1.Image = negative_filling;
            });
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }
       
        //Horizontal Flip Button
        private void horizontal_flip_btn_Click(object sender, EventArgs e)
        {
            Task task = Task.Factory.StartNew(() =>
            {
                Image picture = pictureBox1.Image;
                methods.Horizontal_flip(picture);
                this.pictureBox1.Image = picture;
            });
        }
   

        //vertical flip button
        private void vertical_flip_btn_Click(object sender, EventArgs e)
        {
            Task task = Task.Factory.StartNew(() =>
            {

                Image picture = pictureBox1.Image;
                methods.Vertical_flip(picture);
                this.pictureBox1.Image = picture;
            });
        }     

        //Rotate right button
        private void rotate_right_btn_Click(object sender, EventArgs e)
        {
            Task t1 = Task.Factory.StartNew(() =>
            {
                Image picture = pictureBox1.Image;
                methods.Rotate_right(picture);
                this.pictureBox1.Image = picture;
            });

        }
       
        //Rotate Left button
        private void rotate_left_btn_Click(object sender, EventArgs e)
        {
            Task t1 = Task.Factory.StartNew(() =>
            {
                Image picture = pictureBox1.Image;
                methods.Rotate_left(picture);
                this.pictureBox1.Image = picture;
            });
        }


        //Method to  change RGB
        public void change_RGB()
        {
            float red = red_bar.Value * 0.1f;
            float green = green_bar.Value * 0.1f;
            float blue = blue_bar.Value * 0.1f;
            float brightness = brightness_bar.Value * 0.1f;

            label_red.Text = red.ToString();
            label_green.Text = green.ToString();
            label_blue.Text = blue.ToString();
            label_brightness.Text = brightness.ToString();

            picture_refresh();

            Image pic = pictureBox1.Image;
            Bitmap bitmap = new Bitmap(pic.Width, pic.Height);
            ImageAttributes imageAttributes = new ImageAttributes();
            ColorMatrix colorMatrix = new ColorMatrix(new float[][]
            {
                new float[]{1+red,0 ,0 ,0 , 0 ,},
                new float[]{0 ,1+green, 0, 0, 0,},
                new float[]{0, 0,1+blue, 0, 0 ,},
                new float[]{0, 0, 0, 1, 0},
                new  float[]{brightness,brightness,brightness, 0, 1}
            });

            imageAttributes.SetColorMatrix(colorMatrix);
            Graphics graphics = Graphics.FromImage(bitmap);
            graphics.DrawImage(pic, new Rectangle(0, 0, pic.Width, pic.Height), 0, 0, pic.Width, pic.Height, GraphicsUnit.Pixel, imageAttributes);
            graphics.Dispose();
            pictureBox1.Image = bitmap;

        }


        public void picture_refresh()
        {
            pictureBox1.Image = picture;

        }

        //RED Scroll bar
        private void red_bar_Scroll(object sender, EventArgs e)
        {
            change_RGB();
        }

        //GREEN Scroll bar
        private void green_bar_Scroll(object sender, EventArgs e)
        {
            change_RGB();
        }


        //BLUE Scroll bar
        private void blue_bar_Scroll(object sender, EventArgs e)
        {
            change_RGB();
        }

        //BRIGHTNESS Scroll bar
        private void brightness_bar_Scroll(object sender, EventArgs e)
        {
            change_RGB();
        }

        //Reset button
        private void button4_Click(object sender, EventArgs e)
        {
            reset_image();
        }


        //Reset image function
        public void reset_image()
        {

            if (!openimage_picture)
            {
                MessageBox.Show("Please edit the image");
            }
            else
            {
                if (openimage_picture)
                {
                    picture = Image.FromFile(openFileDialog1.FileName);
                    pictureBox1.Image = picture;
                    openimage_picture = true;

                    Task t1none = new Task(() =>
                    {
                        none();
                    });
                    t1none.Start(TaskScheduler.FromCurrentSynchronizationContext());
                }
            }
        }

        //Crop button (Goes to crop form)
        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Crop cr = new Crop();
            cr.Show();
        }      

        //Bar change to 0 method
        public void none()
        {
            
            Task task1 = new Task(() =>
            {
                pictureBox1.Image = picture;

                this.red_bar.Value = 0;
                this.green_bar.Value = 0;
                this.blue_bar.Value = 0;
                this.brightness_bar.Value = 0;
            });

            task1.Start(TaskScheduler.FromCurrentSynchronizationContext());
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void editMoreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Edit_more edit_More = new Edit_more();
            edit_More.Show();
        }

        //Menu strip Add image
        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Add_Image();
        }

        //Menu strip Save picture
        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Save_picutre();
        }

        //Menu strip Delete Picture
        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Delete_Picture();
        }

        //Menu strip Reset Image
        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {
            reset_image();
        }


        private void cropImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Crop cr = new Crop();
            cr.Show();
        }
    }
}





